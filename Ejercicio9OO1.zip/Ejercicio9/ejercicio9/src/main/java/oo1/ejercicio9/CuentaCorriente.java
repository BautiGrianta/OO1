package oo1.ejercicio9;

public class CuentaCorriente extends Cuenta{
	private double limite;
	
	public CuentaCorriente() {
		this.limite = 0;
	}
	
	public void setDescubierto(double limite) {
		this.limite = limite;
	}
	
	public double getDescubierto() {
		return limite;
	}
	
	public boolean puedeExtraer(double monto) {
		if(this.getSaldo() + limite >= monto ) 
			return true;
		else
			return false;
	}
}
