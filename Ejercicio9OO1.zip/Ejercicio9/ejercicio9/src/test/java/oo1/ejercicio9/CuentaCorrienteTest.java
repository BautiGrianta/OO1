package oo1.ejercicio9;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CuentaCorrienteTest {
	private CuentaCorriente caja1;
	
	@BeforeEach
	public void setup() {
		caja1 = new CuentaCorriente();
	}
	
	@Test
	void testExtraer() {
		assertFalse(caja1.extraer(1));
		caja1.setDescubierto(100);
		assertTrue(caja1.extraer(100));
	}
}
