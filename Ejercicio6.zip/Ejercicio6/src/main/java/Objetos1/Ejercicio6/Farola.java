package Objetos1.Ejercicio6;
import java.util.List;
import java.util.ArrayList;

public class Farola {
	
	private boolean encendido;
	private List<Farola> vecinas;
	
	
	/*
	* Crear una farola. Debe inicializarla como apagada
	*/
	public Farola () {
		encendido = false;
		vecinas = new ArrayList<Farola>();
	}
	
	/*
	* Crea la relación de vecinos entre las farolas. La relación de vecinos entre las farolas es recíproca, es decir el receptor del mensaje será vecino de otraFarola, al igual que otraFarola también se convertirá en vecina del receptor del mensaje
	*/
	public void pairWithNeighbor(Farola otraFarola) {
		if (!vecinas.contains(otraFarola)) {
			vecinas.add(otraFarola);
			otraFarola.pairWithNeighbor(this);
		}
	}
	/*
	* Retorna sus farolas vecinas
	*/
	public List<Farola> getNeighbors (){
		return vecinas;		
	}


	/*
	* Si la farola no está encendida, la enciende y propaga la acción.
	*/
	public void turnOn() {
		if (!encendido) {
			encendido = true;
			for (Farola vecina: vecinas) {
				vecina.turnOn();
			}
		}
	}

	/*
	* Si la farola no está apagada, la apaga y propaga la acción.
	*/
	public void turnOff() {
		if (encendido) {
			encendido = false;
			for (Farola vecina: vecinas) {
				vecina.turnOff();
			}
		}		
	}

	/*
	* Retorna true si la farola está encendida.
	*/
	public boolean isOn() {
		return encendido;
	}

}
