package oo1.ejercicio9;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CajaDeAhorroTest {
	private CajaDeAhorro caja;
	private CajaDeAhorro caja2;
	
	@BeforeEach
	public void setup() {
		caja = new CajaDeAhorro();
	}
	
	
	@Test
	void testDepositar() {
		caja.depositar(1000);
		assertEquals(980, this.caja.getSaldo());
	}
	
	@Test
	void testExtraerPositivo() {
		caja.depositar(1000);
		assertTrue(caja.extraer(960.784313725));
	}
	
	@Test
	void testExtraerNegativo() {
		caja.depositar(1000);
		assertFalse(caja.extraer(961));	
	}
	
	@Test
	void testTransferir() {
		caja2 = new CajaDeAhorro();
		caja.depositar(1000);
		assertTrue(caja.transferirACuenta(960.784313725, caja2));
	}

}
