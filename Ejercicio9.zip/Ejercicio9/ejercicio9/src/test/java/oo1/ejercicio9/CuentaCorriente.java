package oo1.ejercicio9;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CuentaCorriente {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
